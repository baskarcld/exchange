module.exports = {
  plugins: {
    "@tailwindcss/jit": {},
    autoprefixer: {},
  },
  theme: {},
};
