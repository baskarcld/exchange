## Machine ideas

Video/audio playback controls
Payment checkout
Shopping cart
Websocket connection with retry logic
Role-based access
Web-based video call with controls (muting/unmuting)
Data grid
Advanced search area with pagination

CRUD - list page with search bar, pagination and orderable column headings

## Visual ideas

Do syntax highlighting for JSON blocks

### SSR

Improve SSR for SEO concerns
Make the MDX render on the server
